package com.company;

public class Screen {
    public final static int width=800;
    public final static int heigth=800;
}
